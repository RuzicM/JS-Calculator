function getHistory(){
     return document.getElementById("history-value").innerHTML;

}
function printHistory(num){
    document.getElementById("history-value").innerHTML = num;
}
 function printOutput(num){
     if (num === ""){
        document.getElementById("output-value").innerHTML = num;
    }else{
        document.getElementById("output-value").innerHTML = getFormatedNumber(num);
         
    }
}
 function getFormatedNumber(num){
     var n = Number(num);
     var value = n.toLocaleString("en");
     return value;
 }
 function getOutput(){
     return document.getElementById("output-value").innerHTML;
 }

 function reverseNumberFormat(num){
     return Number(num.replace(/,/g,''));
 }

 var operation = document.getElementsByClassName("operant");
 for (let i = 0; i < operation.length; i++){
     operation[i].addEventListener('click', function(){
        if (this.id === "clear"){
            printHistory("");
            printOutput("");
        }
        if( this.id === "backspace"){
            var output = reverseNumberFormat(getOutput()).toString();
            if(output){
                output = output.substr(0,output.length -1);
                printOutput(output);
            }
        }else {
            var output = getOutput();
            var history = getHistory();
         if(output != "") {
            output = reverseNumberFormat(output);
            history = history + output;
            if(this.id === "="){
                var result = eval(history);
                printOutput(result);
                printHistory("");
            }else {
                history = history + this.id;
                printHistory(history);
                printOutput("");
            }

        }
    }
           
    });
 }
 var numbers = document.getElementsByClassName("number");
 for (let i = 0; i < numbers.length; i++){
     numbers[i].addEventListener('click', function(){
    
        let res = reverseNumberFormat(getOutput());
         if (res != NaN){
            res = res + this.id;
            printOutput(res);
        }    
        
     });
 }
 